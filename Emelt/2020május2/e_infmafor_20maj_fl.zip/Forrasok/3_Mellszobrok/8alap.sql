SELECT DISTINCT hely
FROM szobor
WHERE hely IN ( )
AND szemely='Liszt Ferenc';
